return {
	skin = {
		["Panda Skin"] = "cc_skin_panda.png",
	["Pig Skin"] = "cc_skin_pig.png",
	["Special Skin"] = "cc_skin_special.png",
	}, 	

face = {
      ["Happy Face"] = "cc_face_happy.png",
      ["Troll Face"] = "cc_face_troll.png",
      ["XD Face"] = "cc_face_xd.png",
 ["Strange Face"] = "cc_face_strange.png",
 ["Boom Face"] = "cc_face_boom.png",
 ["None Face"] = "none.png",
	},

tshirt = {
      ["None T-Shirt"] = "none.png",
      ["Green T-Shirt"] = "cc_tshirts_green.png",
     ["Blue T-Shirt"] = "cc_tshirts_blue.png",
     ["Red T-Shirt"] = "cc_tshirts_red.png",
     ["Yellow T-Shirt"] = "cc_tshirts_yellow.png",
     ["Orange T-Shirt"] = "cc_tshirts_orange.png",
     ["Purple T-Shirt"] = "cc_tshirts_pink.png",
     ["White T-Shirt"] = "cc_tshirts_white.png",
     ["Black T-Shirt"] = "cc_tshirts_black.png",
	},

pants = {
      ["None Pants"] = "none.png",
        ["Green Pants"] = "cc_pants_green.png",
     ["Blue Pants"] = "cc_pants_blue.png",
     ["Red Pants"] = "cc_pants_red.png",
     ["Yellow Pants"] = "cc_pants_yellow.png",
     ["Orange Pants"] = "cc_pants_orange.png",
     ["Purple Pants"] = "cc_pants_pink.png",
     ["White Pants"] = "cc_pants_white.png",
     ["Black Pants"] = "cc_pants_black.png",
	},

shoes = {
      ["None Shoes"] = "none.png",
       ["Green Shoes"] = "cc_shoes_green.png",
     ["Blue Shoes"] = "cc_shoes_blue.png",
     ["Red Shoes"] = "cc_shoes_red.png",
     ["Yellow Shoes"] = "cc_shoes_yellow.png",
     ["Orange Shoes"] = "cc_shoes_orange.png",
     ["Purple Shoes"] = "cc_shoes_pink.png",
     ["White Shoes"] = "cc_shoes_white.png",
     ["Black Shoes"] = "cc_shoes_black.png",
	},
	
}
