dofile(minetest.get_modpath("inventory_plus") .. "/menu.lua")
dofile(minetest.get_modpath("inventory_plus") .. "/stuff.lua")
