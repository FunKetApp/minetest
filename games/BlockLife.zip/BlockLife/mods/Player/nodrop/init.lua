function minetest.item_drop(itemstack, dropper, pos)

return itemstack

end