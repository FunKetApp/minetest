ma_pops_furniture = {}

dofile(minetest.get_modpath('ma_pops_furniture')..'/nodes.lua')

local MP = minetest.get_modpath(minetest.get_current_modname())
