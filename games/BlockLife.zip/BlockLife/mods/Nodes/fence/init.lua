dofile(minetest.get_modpath("fence").."/cheapwood.lua")
