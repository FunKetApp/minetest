--
--SPAWNING: [true --or-- false]
--


dofile(minetest.get_modpath("ccmobs").."/api.lua")
dofile(minetest.get_modpath("ccmobs").."/mobs.lua")

	mobs:register_spawn("ccmobs:white", {"color:green"}, 20, 8, 8000, 1, 31000)
   mobs:register_spawn("ccmobs:black", {"color:green"}, 20, 8, 8000, 1, 31000)
   mobs:register_spawn("ccmobs:red", {"color:green"}, 20, 8, 8000, 1, 31000)
mobs:register_spawn("ccmobs:green", {"color:green"}, 20, 8, 8000, 1, 31000)
mobs:register_spawn("ccmobs:blue", {"color:green"}, 20, 8, 8000, 1, 31000)
   mobs:register_spawn("ccmobs:yellow", {"color:green"}, 20, 8, 8000, 1, 31000)
mobs:register_spawn("ccmobs:orange", {"color:green"}, 20, 8, 8000, 1, 31000)
mobs:register_spawn("ccmobs:pink", {"color:green"}, 20, 8, 8000, 1, 31000)
   
   
   
   
   
