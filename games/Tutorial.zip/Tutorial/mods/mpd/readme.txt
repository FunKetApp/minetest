 
### mpd Mod for Minetest
(c) 2017 orwell96
Slightly modified for the Tutorial.

This mod is licensed under the MIT License.

Adds an easy but powerful background music backend.

Music credits:

File: SDP.ogg
* Original file name: СДП (средневековая тема 1).mp3
* Author: Alexandr Zhelanov
* License: CC BY 3.0 <https://creativecommons.org/licenses/by/3.0/>
* Source: https://opengameart.org/content/old-music
