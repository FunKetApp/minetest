------------------------------------------------------
-- Darkage mod by MasterGollum, addi and CraigyDavi --
-- TUTORIAL EDITION --
------------------------------------------------------

dofile(minetest.get_modpath("darkage").."/nodes.lua")

--
-- Config
--

print ("Darkage Tutorial Edition [darkage] has loaded!")
