=-=-=-=-=-=-=-=-=-=

Castles Mod - Tutorial Edition
by: Philipbenr And DanDuncombe

HEAVILY MODIFIED FOR THE TUTORIAL

=-=-=-=-=-=-=-=-=-=

Licence: GPLv3

see: LICENSE

=-=-=-=-=-=-=-=-=-=

This is a mod all about creating castles and castle dungeons. Many of the nodes are used for the outer-walls or dungeons.
It was stripped down to the neccessary parts for the Tutorial.

=-=-=-=-=-=-=-=-=-=

Contains as of now:

--Walls, Corner-walls,
--Castlestone Stairs, Slabs, and Pillars
--Jailbars
--Hides
--Arrowslits
--Rubble (for between walls)
--Doors
--and more!

=-=-=-=-=-=-=-=-=-=
"  Although crossbows have been removed, along with arrows, the code is still there.
   To get the crossbows back, look in init.lua. You will see at the top some lines 
   with dofile in them. Copy and paste two more of these lines, and change them to
   crossbow.lua and arrow.lua to get them back. "
   
I, (philipbenr) will take a look at the arrows and crossbows, and see about this.
