Areas mod for Minetest 0.4.8+
=============================

This mod is a stripped-down version of the Areas mod for the tutorial.
It only is used for the text “You are here: (some location)” in the upper right
corner. 

License
-------

Copyright (C) 2013 ShadowNinja

Licensed under the GNU LGPL version 2.1 or later.
See http://www.gnu.org/licenses/lgpl-2.1.txt

